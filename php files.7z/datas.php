<?php
$dbURL="localhost";
$dbName="transport";
$dbusername="root";
$dbpassword="database";
$dbdetails=array(
    'url'=>$dbURL,
    'name'=>$dbName,
    'username'=>$dbusername,
    'password'=>$dbpassword
);

?>
